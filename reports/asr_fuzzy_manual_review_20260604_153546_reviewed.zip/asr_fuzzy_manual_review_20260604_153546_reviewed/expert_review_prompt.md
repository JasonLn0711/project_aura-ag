# Expert Review Prompt: ASR Fuzzy Correction Manual Gate

You are reviewing an ASR post-processing glossary correction queue for a research-grade meeting transcript tool.

Please open:

```text
asr_fuzzy_manual_review_queue.csv
```

For each row, fill `review_label` with exactly one of:

```text
ACCEPT
REJECT
UNSURE
```

Use this decision rule:

- `ACCEPT`: The original span is clearly an ASR typo or casing/formatting error, and the corrected span is the correct domain term, person name, organization, product name, medical term, or regulatory term.
- `REJECT`: The correction may change meaning, the original span is already valid, or the corrected span is too aggressive without context.
- `UNSURE`: The correction requires listening to the audio or seeing more transcript context.

Important review constraints:

- Do not infer missing context.
- Do not approve a correction just because the corrected term looks familiar.
- Be stricter for people names, medical terms, numeric/regulatory terms such as `510(k)`, and terms that may affect negation or dates.
- The queue intentionally contains only correction spans and source transcript filenames. It does not include raw transcript context, Gmail content, or PDF content.

After labeling:

1. Save the CSV with the same columns.
2. Do not delete any rows.
3. Do not edit `source_file`, `category`, `original`, `corrected`, `score`, or `watch_flag`.
4. Use `review_note` only when `REJECT` or `UNSURE` needs a short reason.

Decision after review:

- If every row is `ACCEPT`, the ASR fuzzy correction feature can proceed to commit.
- If any row is `REJECT`, those cases should become denylist entries or trigger a stricter threshold/alias change.
- If any row is `UNSURE`, that pattern should not be auto-corrected; route it to manual review behavior.
